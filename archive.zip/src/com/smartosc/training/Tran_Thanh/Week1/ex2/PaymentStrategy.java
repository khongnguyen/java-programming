package Week1.ex2;

public interface PaymentStrategy {
	public void pay(int money);
}