package Week1.hw.oop;

public enum Type {
	Exciter, Raider, AirBlade;
}
